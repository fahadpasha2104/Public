/* Code to prevent WCRY infection on an unpatched host, registers
   the mutex used by the worm to prevent an infection from being 
   spread to the host. Innoculates the host by registering the 
   same mutex.
   
   Compile with cl.exe /MT WCRYSLAP.cpp 
    -- Hacker Fantastic (www.myhackerhouse.com)
*/
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <tchar.h>
#include <Windows.h>
#include <strsafe.h>

int _tmain(int argc, _TCHAR* argv[])
{
	HANDLE hMutexoneInstance = CreateMutex(NULL,TRUE,"MsWinZonesCacheCounterMutexA");
	if(GetLastError()== ERROR_ALREADY_EXISTS){
		printf("This machine is infected with WCRY worm already\n");
		while(1){
			Sleep(10000);
		}
	}
	printf("WCRY Worm innoculation - minimize but do not close this task");
	while(1){
		Sleep(10000);
	}
	return 0;
}